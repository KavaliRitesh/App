import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from '../shared.service';
import { CarService, Car } from '../services/car.service'; // Import CarService and Car interface

@Component({
  selector: 'app-vehicletypes',
  templateUrl: './vehicletypes.component.html',
  styleUrls: ['./vehicletypes.component.css']
})
export class VehicletypesComponent {
  locations: string[] = ["Banglore", "Chennai", "Hyderbad", "Mumbai"];
  selectlocation: string = '';
  pickupdate: string = '';
  today: string = new Date().toISOString().split('T')[0];
  returndate: string = '';

  categories: string[] = ['economy', 'premier', 'luxury'];
  selectcategory: string = '';
  cars: Car[] = []; // Use backend Car interface
  filteredcars: Car[] = [];
  selectedcars: Car | null = null;

  constructor(
    private router: Router,
    private sharedService: SharedService,
    private carService: CarService // Inject CarService
  ) {
    // Fetch cars from backend on component init
    this.carService.getAvailableCars().subscribe((cars) => {
      this.cars = cars;
      this.filteredcars = cars;
      this.selectedcars = cars[0] || null;
    });
  }

  formvalid() {
    return (this.selectlocation && this.pickupdate && this.returndate && this.selectcategory);
  }

  oncategorychange() {
    this.filteredcars = this.cars.filter(car => car.carCategory === this.selectcategory);
    this.selectedcars = this.filteredcars[0] || null;
  }

  public selectcar(car: Car) {
    this.selectedcars = car;
  }

  public booknow() {
    if (this.selectedcars) {
      this.sharedService.setCityAndCar(this.selectlocation, this.selectedcars.make, this.selectcategory, this.pickupdate, this.returndate);
      this.router.navigate(['/carlist']);
    }
  }
}

// Note:
// - Removed the hardcoded cars array (now using backend).
// - Using backend field names (make, model, carCategory, imageUrl, etc).
// - Use CarService to fetch cars from backend.
// - Use selectedcars.make instead of selectedcars.name.