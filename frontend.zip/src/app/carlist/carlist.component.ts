import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { CarService, Car } from '../services/car.service';
import { RentalService } from '../services/rental.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-carlist',
  templateUrl: './carlist.component.html',
  styleUrls: ['./carlist.component.css']
})
export class CarlistComponent implements OnInit {
  city: string = '';
  carCategory: string = '';
  imageCards: string[] = [];
  selectedCar: Car | null = null;
  pickupdate: string = '';
  returndate: string = '';

  constructor(private sharedService: SharedService, private carService: CarService, private rentalService: RentalService, private router: Router) { }

  ngOnInit(): void {
    const { city, carname, car1 } = this.sharedService.getCityAndCar();
    this.city = city;
    this.carCategory = car1; // car1 holds the selected category
    this.pickupdate = this.sharedService['pickupdate'] || '';
    this.returndate = this.sharedService['returndate'] || '';

    // Fetch cars and filter by category
    this.carService.getAvailableCars().subscribe((cars) => {
      const found = cars.find(car => car.make === carname && car.carCategory === car1);
      if (found) {
        this.selectedCar = found;
        // Exclude imageUrl[0], use the rest for cards
        this.imageCards = found.imageUrl.slice(1);
      }
    });
  }

  bookNow(carId: string) {
    // Use your actual rentalStartDate and rentalEndDate variables here
    this.rentalService.bookCar(carId, this.pickupdate, this.returndate).subscribe({
      next: () => {
        alert('Booking confirmed!');
        this.router.navigate(['/profile']);
      },
      error: (err) => {
        alert('Booking failed: ' + (err.error?.message || 'Please try again.'));
      }
    });
  }
}