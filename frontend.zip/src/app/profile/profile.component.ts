import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { RentalService } from '../services/rental.service';
import { ApiRental } from '../adminmodels';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  check: string = 'all';
  user: any = {};
  bookings: ApiRental[] = [];
  loading: boolean = false;
  error: string = '';

  constructor(private authService: AuthService, private rentalService: RentalService) { }

  ngOnInit(): void {
    // Here you can fetch real booking data later from backend/API
    const user = localStorage.getItem('user');
    if (user) {
      this.user = JSON.parse(user);
    }
    this.fetchBookings();
  }

  fetchBookings(): void {
    this.loading = true;
    this.rentalService.getUserRentals().subscribe({
      next: (rentals) => {
        this.bookings = rentals;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load bookings';
        this.loading = false;
      }
    });
  }

  cancelBooking(book: ApiRental): void {
    if (!book._id) return;
    if (!confirm('Are you sure you want to cancel this booking?')) return;
    this.rentalService.cancelBooking(book._id).subscribe({
      next: () => {
        // Refresh bookings after cancellation
        this.fetchBookings();
      },
      error: () => {
        alert('Failed to cancel booking. Please try again.');
      }
    });
  }

  get filteredCars(): ApiRental[] {
    if (this.check === 'all') return this.bookings;
    // Map backend status to UI status if needed
    return this.bookings.filter(book => {
      if (this.check === 'Active') return book.status === 'booked' || book.status === 'rented';
      if (this.check === 'Completed') return book.status === 'completed';
      if (this.check === 'cancelled') return book.status === 'cancelled';
      return true;
    });
  }

  isApiCar(car: any): car is { make: string } {
    return car && typeof car === 'object' && 'make' in car;
  }
}


