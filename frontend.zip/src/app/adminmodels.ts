// API models (for backend integration)
export interface ApiCar {
  _id: string;
  make: string;
  model: string;
  cartype: string;
  carCategory: string;
  pricePerKm: number;
  pricePerDay: number;
  imageUrl: string[];
  features: string[];
}

export interface ApiRental {
  _id: string;
  car: ApiCar | string;
  rentalStartDate: string;
  rentalEndDate: string;
  status: string;
  [key: string]: any;
}