import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ApiCar, ApiRental } from "../adminmodels";

@Injectable({
    providedIn: 'root',
})
export class RentalService {
    private apiUrl = 'http://localhost:3000/api/rentals';

    constructor(private http: HttpClient) { }

    // Book a car (create rental)
    bookCar(carId: string, rentalStartDate: string, rentalEndDate: string): Observable<ApiRental> {
        const token = localStorage.getItem('token');
        return this.http.post<ApiRental>(
            this.apiUrl,
            { carId, rentalStartDate, rentalEndDate },
            { headers: { Authorization: `Bearer ${token}` } }
        );
    }

    // Get all rentals for the logged-in user
    getUserRentals(): Observable<ApiRental[]> {
        const token = localStorage.getItem('token');
        return this.http.get<ApiRental[]>(this.apiUrl, {
            headers: { Authorization: `Bearer ${token}` }
        });
    }

    cancelBooking(rentalId: string): Observable<any> {
        const token = localStorage.getItem('token');
        return this.http.delete(`${this.apiUrl}/${rentalId}`, {
            headers: { Authorization: `Bearer ${token}` }
        });
    }
}