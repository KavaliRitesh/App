import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CarServiceService } from '../services/car-service.service';
interface RentalDetails {
  pricePerKm: number;
  discount: number;
  perDayCost: number;
}

interface Car {
  _id: string;
  name: string;
  image: string;
  model: string;
  type: 'basic' | 'mid-range' | 'high-end';
  rentalDetails: RentalDetails;
  userDistance?: number;
  rentalDays?: number;
  details: string;
  gearType: 'manual' | 'automatic';
  isFrequentRenter?: boolean;
  loyaltyPoints?: number;
  extraDiscountRides?: number;
}
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {


  // ngOnInit() {
  //   // Check if the admin is authenticated
  //     this.router.navigate(['/login']); // Redirect to login if not authenticated
  // }

  // Navigate to different sections

  cars: Car[] = [];
  selectedType: string = 'all';
  selectedGearType: string = 'all';
  editingCarId: string | null = null; // Track which car is being edited
  currentPage: string = '';
  allRentals: any[] = [];
  pickupOdometerInputs: { [rentalId: string]: number } = {};
  returnOdometerInputs: { [rentalId: string]: number } = {};
  constructor(private carService: CarServiceService, private router: Router) { }


  // Function to set the current page
  setPage(page: string): void {
    this.currentPage = page;
    if (page === 'viewRentals') {
      this.fetchAllRentals();
    }
  }

  ngOnInit(): void {
    this.fetchAllRentals();
  }

  fetchAllRentals(): void {
    this.carService.getAllRentals().subscribe(
      (data) => {
        this.allRentals = data;
      },
      (error) => {
        console.error('Error fetching rentals:', error);
      }
    );
  }

  pickupCar(rental: any): void {
    const odometer = this.pickupOdometerInputs[rental._id];
    if (!odometer || odometer < 0) {
      alert('Please enter a valid pickup odometer value.');
      return;
    }
    this.carService.pickupCar(rental._id, odometer).subscribe(
      (res) => {
        // Mark as picked up locally to update UI instantly
        rental._pickupDone = true;
        rental.status = 'rented';
        alert('Car pickup successful!');
      },
      (err) => {
        alert('Failed to pickup car: ' + (err.error?.message || 'Unknown error'));
      }
    );
  }

  completeRide(rental: any): void {
    const odometer = this.returnOdometerInputs[rental._id];
    if (!odometer || odometer < 0) {
      alert('Please enter a valid return odometer value.');
      return;
    }
    this.carService.returnCar(rental._id, odometer).subscribe(
      (res) => {
        rental._rideCompleted = true;
        rental.status = 'completed';
        alert('Ride completed successfully!');
      },
      (err) => {
        alert('Failed to complete ride: ' + (err.error?.message || 'Unknown error'));
      }
    );
  }

  enableEdit(carId: string): void {
    this.editingCarId = carId; // Set the car ID being edited
  }

  saveCar(car: Car): void {
    this.carService.updateCar(car._id, car).subscribe(
      (response) => {
        alert(`Car ${car.name} updated successfully!`);
        this.editingCarId = null; // Exit edit mode
        this.fetchAllRentals(); // Refresh the car list
      },
      (error) => {
        console.error('Error updating car:', error);
      }
    );
  }

  cancelEdit(): void {
    this.editingCarId = null; // Exit edit mode without saving
  }
  deleteCar(carId: string): void {
    console.log('Attempting to delete car with ID:', carId); // Debug log
    if (confirm('Are you sure you want to delete this car?')) {
      this.carService.deleteCar(carId).subscribe(
        (response) => {
          console.log('Delete response:', response); // Debug log
          alert('Car deleted successfully.');
          this.fetchAllRentals(); // Refresh the car list
        },
        (error) => {
          console.error('Error deleting car:', error);
          alert('Failed to delete the car. Please try again.');
        }
      );
    }
  }
  // previousRentals = [
  //   { carName: 'Car 1', rentalDate: '2025-05-01', returnDate: '2025-05-05' },
  //   { carName: 'Car 2', rentalDate: '2025-04-15', returnDate: '2025-04-20' }
  // ];
}