import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http'; 

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  profileForm!: FormGroup;

  constructor(private fb: FormBuilder, private router: Router, private http: HttpClient) { }

  ngOnInit(): void {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    this.profileForm = this.fb.group({
      name: [user.name || '', Validators.required],
      email: [user.email || '', [Validators.required, Validators.email]],
      phone: [user.phone || '', Validators.required],
      avatar: [user.avatar || 'assets/profile.png'],
    });
  }
  changePassword(): void {
    this.router.navigate(['/changepassword']);// when integrated will be directed to reset password page
  }
  onSubmit() {
    if (this.profileForm.valid) {
      const token = localStorage.getItem('token');
      this.http.put(
        'http://localhost:3000/api/users/profile',
        this.profileForm.value,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      ).subscribe({
        next: (res: any) => {
          // Update localStorage with new user data
          const updatedUser = { ...JSON.parse(localStorage.getItem('user') || '{}'), ...this.profileForm.value };
          localStorage.setItem('user', JSON.stringify(updatedUser));
          this.router.navigate(['/profile']);
        },
        error: (err) => {
          alert('Failed to update profile!');
        }
      });
    }
  }
}
