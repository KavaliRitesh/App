module.exports = {
  url: 'mongodb://localhost:27017/car_rental', // MongoDB connection URL
};