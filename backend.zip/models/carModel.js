const mongoose = require('mongoose');

const carSchema = new mongoose.Schema({
  make: { type: String, required: true },
  model: { type: String, required: true },
  cartype: { 
    type: String, 
    required: true,
    enum: ['hyundai', 'sedan', 'suv', 'force', 'honda'] 
  },
  carCategory: { 
    type: String, 
    required: true,
    enum: ['economy', 'premier', 'luxury'] 
  },
  year: { type: Number, required: true },
  pricePerKm: { 
    type: Number,
    required: true,
    min: [0.01, 'Price per km must be positive'], // Minimum 0.01
    validate: {
      validator: Number.isFinite,
      message: 'Price per km must be a valid number'
    }
   },
  pricePerDay: { 
    type: Number,
    required: true,
    min: [0.01, 'Price per day must be positive'], // Minimum 0.01
    validate: {
      validator: Number.isFinite,
      message: 'Price per day must be a valid number'
    }
  },
  availabilityStatus: { 
    type: String, 
    enum: ['available', 'rented', 'maintenance'], 
    default: 'available' 
  },
  currentOdometer: { type: Number, required: true },
  imageUrl: [String],
  features: [String]
}, { timestamps: true });


module.exports = mongoose.model('Car', carSchema);