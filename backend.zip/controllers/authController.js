const AuthService = require('../services/authService');
const { validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const User = require('../models/userModel');
const jwt = require('jsonwebtoken');
const config = require('../config');

class AuthController {
  async register(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        console.error("The data is incorrect")
        return res.status(400).json({ errors: errors.array() });
      }
      const user = await AuthService.register(req.body);
      const token = jwt.sign(
        { 
          email: user.email, 
          role: user.role 
        },
        config.JWT_SECRET,
        { expiresIn: '30d' }
      );
      const userResponse = {
        name: user.name,
        phone: user.phone,
        email: user.email,
        role: user.role,
      };
      res.status(201).json({ 
        user: userResponse,
        token 
      });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async login(req, res) {
    try {
      const { email, password } = req.body;
      const { user, token } = await AuthService.login(email, password);
      res.json({ user, token });
    } catch (error) {
      res.status(401).json({ message: error.message });
    }
  }
  

  async createAdmin(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      const admin = await AuthService.createAdmin(req.body);
      res.status(201).json(admin);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
}

module.exports = new AuthController();