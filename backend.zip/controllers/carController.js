const CarService = require('../services/carService');
const path = require('path')

class CarController {
  async createCar(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }

      let imageUrl = [];
    if (req.files && req.files.length > 0) {
      imageUrl = req.files.map(file => `/uploads/${file.filename}`);
    }

    // Parse numbers from req.body
    const carData = {
      make: req.body.make,
      model: req.body.model,
      cartype: req.body.cartype,
      carCategory: req.body.carCategory,
      year: Number(req.body.year),
      pricePerKm: Number(req.body.pricePerKm),
      pricePerDay: Number(req.body.pricePerDay),
      currentOdometer: Number(req.body.currentOdometer),
      imageUrl,
      features: Array.isArray(req.body.features) ? req.body.features : [req.body.features]
      
    };

    const car = await CarService.createCar(carData);
    res.status(201).json(car);
    } catch (error) {
      console.log("you are not admin")
      res.status(400).json({ message: error.message });
    }
  }

  async updateCarImageAtIndex(req, res) {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden' });
    }

    const carId = req.params.id;
    const index = parseInt(req.body.index, 10);

    if (!req.file) {
      return res.status(400).json({ message: 'No image uploaded' });
    }

    const filePath = `/uploads/${req.file.filename}`;
    const car = await CarService.getCarById(carId);
    if (!car) {
      return res.status(404).json({ message: 'Car not found' });
    }

    // Update the imageUrl at the specified index
    car.imageUrl[index] = filePath;
    await car.save();

    res.json(car);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
}

  async updateCar(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }

      let imageUrl = [];
    if (req.files && req.files.length > 0) {
      imageUrl = req.files.map(file => `/uploads/${file.filename}`);
    }

    // Parse numbers from req.body
    const carData = {
      make: req.body.make,
      model: req.body.model,
      cartype: req.body.cartype,
      carCategory: req.body.carCategory,
      year: Number(req.body.year),
      pricePerKm: Number(req.body.pricePerKm),
      pricePerDay: Number(req.body.pricePerDay),
      currentOdometer: Number(req.body.currentOdometer),
      features: Array.isArray(req.body.features) ? req.body.features : [req.body.features]    };

    const car = await CarService.createCar(carData);
    res.status(201).json(car);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async deleteCar(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      await CarService.deleteCar(req.params.id);
      res.json({ message: 'Car deleted successfully' });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getAvailableCars(req, res) {
    try {
      const cars = await CarService.getAvailableCars();
      res.json(cars);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getCarsByType(req, res) {
    try {
      const cars = await CarService.getCarsByType(req.params.cartype);

      if (!cars || cars.length === 0) {
        return res.status(404).json({ message: 'No cars found for this type' });
      }

      // Return the first matching car with required fields
      const response = cars.map(car => ({
        make: car.make,
        model: car.model,
        imageUrl: car.imageUrl[0],  // Primary image
        luggage: car.features[2],   // Luggage info from features[2]
        mileage: car.features[1],   // Mileage info from features[1]
        refundPolicy: car.features[3] // Refund policy from features[3]
      }));

      res.json(response);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getCarById(req, res) {
    try {
      const car = await CarService.getCarById(req.params.id);
      res.json(car);
    } catch (error) {
      res.status(404).json({ message: error.message });
    }
  }
}

module.exports = new CarController();