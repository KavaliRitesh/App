const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const config = require('./config');
const path=require('path');
const fs = require('fs');

// Import routes
const authRoutes = require('./routes/authRouter');
const userRoutes = require('./routes/userRouter');
const carRoutes = require('./routes/carRouter');
const taxRoutes = require('./routes/taxRouter');
const rentalRoutes = require('./routes/rentalRouter');

// Initialize Express app
const app = express();
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Connect to MongoDB
mongoose.connect(config.MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/cars', carRoutes);
app.use('/api/taxes', taxRoutes);
app.use('/api/rentals', rentalRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

app.listen(config.PORT, () => {
  console.log(`Server running on port ${config.PORT}`);
});


