const jwt = require('jsonwebtoken');
const config = require('../config');

module.exports = {
  authenticate: (req, res, next) => {
    const authHeader = req.headers['authorization'] || req.headers['Authorization'];
    if (!authHeader) {
      return res.status(401).json({ message: 'No token, authorization denied' });
    }

    const token=authHeader.replace(/^Bearer\s+/i, '')
    console.log("Extracted token: ", token)//debug

    if(!token) {
      return res.status(401).json({message: 'No token, authorization denied'})
    }
    try {
      const decoded = jwt.verify(token, config.JWT_SECRET);
      console.log('Decoded Token Payload: ', decoded)//debug
      req.user = decoded;
      next();
    } catch (error) {
      console.error('JWT Verification Error: ', error)//debug
      res.status(401).json({ message: 'Token is not valid' });
    }
  },

  authorizeAdmin: (req, res, next) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden' });
    }
    next();
  }
};