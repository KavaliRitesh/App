require('dotenv').config();
const mongoose = require('mongoose');
const Tax = require('../models/taxModel');
const User = require('../models/userModel');
const bcrypt = require('bcryptjs');
const config = require('../config');

async function initialize() {
  try {
    await mongoose.connect(config.MONGODB_URI);

    // Create default tax rules
    const taxRules = [
      { carType: 'compact', taxPercentage: 10 },
      { carType: 'sedan', taxPercentage: 10 },
      { carType: 'suv', taxPercentage: 20 },
      { carType: 'minivan', taxPercentage: 20 },
      { carType: 'luxury', taxPercentage: 40 }
    ];

    for (const rule of taxRules) {
      await Tax.findOneAndUpdate(
        { carType: rule.carType },
        rule,
        { upsert: true, new: true }
      );
    }
    console.log('Tax rules initialized');
    process.exit(0);
  } catch (error) {
    console.error('Initialization failed:', error);
    process.exit(1);
  }
}

initialize();