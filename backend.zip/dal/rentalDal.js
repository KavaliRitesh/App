const BaseDAL = require('./baseDal');
const Rental = require('../models/rentalModel');

class RentalDAL extends BaseDAL {
  constructor() {
    super(Rental);
  }

  async findUserRentals(userId, status) {
    try {
      console.log("Searching rentals for:", { userId, status });
      const query = { user: userId };
      
      // Improved status handling
      if (status && status !== 'all') {
        query.status = status === 'previous' 
          ? 'completed' 
          : { $in: ['booked', 'rented'] };
      }

      const result = await this.model.find(query)
        .populate('car')
        .lean() // Convert to plain JS objects
        .exec();

      console.log("Query result:", result);
      return result;
    } catch (error) {
      console.error("Error in findUserRentals:", error);
      throw error;
    }
  }

  async findAllRentals() {
    return await this.model.find()
      .populate('user')
      .populate('car')
      .lean()
      .exec();
  }

  async findRentalWithDetails(id) {
    return await this.model.findById(id)
      .populate('user')
      .populate('car')
      .lean()
      .exec();
  }
}

module.exports = new RentalDAL();