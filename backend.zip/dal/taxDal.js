const BaseDAL = require('./baseDal');
const Tax = require('../models/taxModel');

class TaxDAL extends BaseDAL {
  constructor() {
    super(Tax);
  }

  async findOneAndUpdate(filter, update, options) {
    return await this.model.findOneAndUpdate(filter, update, options);
  }
}

module.exports = new TaxDAL();