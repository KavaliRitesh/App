const express = require('express');
const router = express.Router();
const carController = require('../controllers/carController');
const { authenticate } = require('../middleware/auth');
const upload = require('../config/multer');

// Public routes
router.get('/', carController.getAvailableCars);
router.get('/:id', carController.getCarById);
router.get('/type/:cartype', carController.getCarsByType);

// Admin-only routes
router.use(authenticate);
router.post('/', upload.array('images'), carController.createCar);
router.put('/:id',upload.array('images'),carController.updateCar);
// Add this route for updating a single image at a specific index
router.put('/:id/image', authenticate, upload.single('image'), carController.updateCarImageAtIndex);
router.delete('/:id', carController.deleteCar);

module.exports = router;