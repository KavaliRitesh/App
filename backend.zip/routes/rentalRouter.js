const express = require('express');
const router = express.Router();
const rentalController = require('../controllers/rentalController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

router.post('/', rentalController.bookCar);
router.get('/', rentalController.getUserRentals);
router.get('/all', rentalController.getAllRentals);
router.get('/user/:userId', rentalController.getUserRentalHistory);
router.put('/:id/pickup', rentalController.pickupCar);
router.put('/:id/return', rentalController.returnCar);
router.delete('/:id', rentalController.cancelBooking);

module.exports = router;