const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticate } = require('../middleware/auth');

//forgot password routes
router.post('/forgot-password', userController.requestPasswordReset);
router.patch('/reset-password/:token', userController.resetPasswordToken);

router.use(authenticate);

router.get('/profile', userController.getProfile);
router.put('/profile', userController.updateProfile);
router.put('/change-password', userController.changePassword);
router.delete('/:id', userController.deleteUser);


module.exports = router;


