const UserDAL = require('../dal/userDal');
const jwt = require('jsonwebtoken');
const config = require('../config');

class AuthService {
  async register(userData) {
    const existingUser = await UserDAL.findByEmail(userData.email); // await UserDAL.findByUsername(userData.username) ||
    if (existingUser) {
      throw new Error('email already exists');
    }
    return await UserDAL.create(userData);
  }

  async login(email, password) {
    const user = await UserDAL.findByEmail(email);
    if (!user) {
      throw new Error('User not found');
    }
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      throw new Error('Invalid credentials');
    }
    const token = jwt.sign(
      { id: user._id,  role: user.role }, 
      config.JWT_SECRET, 
      { expiresIn: '1d' }
    );
    return { user, token };
  }

  async createAdmin(adminData) {
    adminData.role = 'admin';
    return await this.register(adminData);
  }
}

module.exports = new AuthService();