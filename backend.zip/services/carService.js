const CarDAL = require('../dal/carDal');

class CarService {
  async createCar(carData) {
    return await CarDAL.create(carData);
  }

  async updateCar(carId, carData) {
    return await CarDAL.updateById(carId, carData);
  }

  async deleteCar(carId) {
    return await CarDAL.deleteById(carId);
  }

  async getAvailableCars() {
    return await CarDAL.findAvailableCars();
  }

  async getCarsByType(carType) {
    return await CarDAL.findByType(carType);
  }

  async getCarById(carId) {
    return await CarDAL.findById(carId);
  }
}

module.exports = new CarService();