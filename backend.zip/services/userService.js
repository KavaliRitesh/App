const UserDAL = require('../dal/userDal');
const { validate } = require('../models/userModel');
const crypto=require('crypto')

class UserService {
  async updateProfile(userId, profileData) {
    return await UserDAL.updateById(userId, profileData);
  }

  async changePassword(userId, currentPassword, newPassword) {
    const user = await UserDAL.findById(userId);
    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      throw new Error('Current password is incorrect');
    }

    if (newPassword.length < 8) {
      throw new Error('Password must be at least 8 characters');
    }

    // Hash and save new password
    user.password = newPassword;
    await user.save(); // This triggers the pre-save hook

    return user;
  }

  async requestPasswordReset(email) {
    const user = await UserDAL.findByEmail(email);
    if (!user) return; // Don't reveal if email exists

    const resetToken=user.createPasswordResetToken();
    await user.save({validateBeforeSave: false});

    return resetToken;
  }

  async deleteUser(userId) {
    return await UserDAL.deleteById(userId);
  }

  async resetPasswordWithToken(token, newPassword, confirmPassword) {
    if(!token) throw new Error("Token is Required");
    if (newPassword !== confirmPassword) throw new Error("Passwords don't match");
    if (newPassword.length < 8) throw new Error('Password must be atleast 8 characters');

    const hashedToken=crypto.createHash('sha256').update(token).digest('hex');
    console.log(hashedToken)

    const user=await UserDAL.findOne({resetToken: hashedToken, resetTokenExpiry: {$gt: Date.now()}})
    if (!user) throw new Error("Token is invalid or has expired")

    const samePassword = await user.comparePassword(newPassword);
    if (samePassword) throw new Error("Cannot use previous password");

    user.password = newPassword;
    user.resetToken=undefined;
    user.resetTokenExpiry=undefined;

    await user.save();
    return user;
  }

  async getUserById(userId) {
    return await UserDAL.findById(userId);
  }
}

module.exports = new UserService();