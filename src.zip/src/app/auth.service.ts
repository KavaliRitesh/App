import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators';
 
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loginUrl = 'http://localhost:5000/login'; // Backend login endpoint
  private loggedIn = new BehaviorSubject<boolean>(false);
  isLoggedIn$ = this.loggedIn.asObservable();
 
  constructor(private http: HttpClient, private router: Router) {
    // Restore login state from localStorage
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (isLoggedIn === 'true') {
      this.loggedIn.next(true);
    }
  }
 
  login(credentials: any): Observable<any> {
    return this.http.post(this.loginUrl, credentials).pipe(
      tap((response: any) => {
        // Save login state and user info on successful login
        this.loggedIn.next(true);
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('user', JSON.stringify(response.user));
      })
    );
  }
 
  logout(): void {
    this.loggedIn.next(false);
    localStorage.setItem('isLoggedIn', 'false');
    localStorage.removeItem('user');
    this.router.navigateByUrl('/home', { replaceUrl: true });
  }
 
  // Optional: get current user info
  getCurrentUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }
}