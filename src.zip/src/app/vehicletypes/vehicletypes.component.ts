import { Component,OnInit} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-vehicletypes',
  templateUrl: './vehicletypes.component.html',
  styleUrls: ['./vehicletypes.component.css']
})
export class VehicletypesComponent implements OnInit{
  cars:any[]=[];
  selectedcars:any;
  constructor(private http:HttpClient,private router:Router)
  {}
ngOnInit():void{
this.http.get<any>('/assets/cars.json').subscribe(data=>
{
  this.cars=data.cars;
  this.selectedcars=this.cars[0];//default car image 1 will be displayed
}
)}
public selectcar(car:any)
{
  this.selectedcars=car;
}
public booknow()
{
  this.router.navigate(['/carlist'])
}
}
