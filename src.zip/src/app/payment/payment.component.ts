import { Component } from '@angular/core';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})


export class PaymentComponent {
  car: Car = {
    modelName: 'Nissan Skyline',
    pickupDate: '2025-05-20',
    endDate: '2025-05-25',
    gearType: 'Manual',
    baseCharges: 4500,
    tax: 500,
    total: 5000,
    imageUrl: '/assets/sedan.jpg'
  };

  paymentMethod: string = '';
  showPopup: boolean = false;

  onPayNow() {
    this.showPopup = true;
  }
  


}
export interface Car {
  modelName: string;
  pickupDate: string;
  endDate: string;
  gearType: string;
  baseCharges: number;
  tax: number;
  total:number;
  imageUrl: string;
}
